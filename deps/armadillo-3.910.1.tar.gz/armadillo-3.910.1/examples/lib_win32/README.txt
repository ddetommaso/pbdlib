The lib and dll files in this folder are for 32 bit Windows XP.
They are compiled versions of the BLAS and LAPACK libraries,
which are distributed under a BSD license.

The compiled versions were downloaded from:
http://www.fi.muni.cz/~xsvobod2/misc/lapack/

Sources for BLAS and LAPACK can be found at:
http://www.netlib.org/blas/
http://www.netlib.org/lapack/
